package com.profamilia.profamilia.repositorio;

import com.profamilia.profamilia.dto.Sede;
import org.springframework.data.jpa.repository.JpaRepository;


public interface SedeRepositorio extends JpaRepository<Sede, Integer> {
}
