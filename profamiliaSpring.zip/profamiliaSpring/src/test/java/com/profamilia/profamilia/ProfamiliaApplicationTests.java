package com.profamilia.profamilia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfamiliaApplicationTests {

	@Test
	void contextLoads() {
	}

}
