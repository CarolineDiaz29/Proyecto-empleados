package com.ProfamiliaExcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfamiliaExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
